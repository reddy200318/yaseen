
# Yaseen Sweets & Bakery

## Frontend
The frontend is built using basic HTML, CSS, and JavaScript.

### To run the frontend:
1. Open `index.html` in your browser.

## Backend
The backend is built with Node.js and Express.js.

### To run the backend:
1. Navigate to the `backend` folder.
2. Run `npm install` to install dependencies.
3. Run `npm start` to start the server on port 3000.

## Deployment
1. Use platforms like Netlify/Vercel for frontend and Heroku/Render for backend.
